Initiate Remote
	Copy this file into the folder you want to link with your Github repository.
	Ope the file in a text-editor and change *YOUR_GITHUB_ACCOUNT* to your github account name.
	Run the file and enter the name of your repository.
	
Update
	Copy this file into the folder you want to push to your github repository.
	Run the file and enter a update message.
	*WARNING* This will push every changed file.